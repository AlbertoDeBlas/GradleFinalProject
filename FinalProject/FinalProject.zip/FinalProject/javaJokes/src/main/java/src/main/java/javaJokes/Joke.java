package src.main.java.javaJokes;


public class Joke {
    private static String FUN_JOKE = "Today at the bank, an old lady asked me to help check her balance. So I pushed her over.";

    public static String retrieveJoke(){
        return FUN_JOKE;
    }
}
